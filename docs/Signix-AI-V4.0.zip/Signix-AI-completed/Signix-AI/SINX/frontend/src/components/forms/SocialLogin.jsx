import Button from "../ui/Button";

function GoogleIcon() {
  return (
    <svg viewBox="0 0 20 20" className="h-4.5 w-4.5" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M19.6 10.23c0-.68-.06-1.36-.18-2H10v3.79h5.4a4.6 4.6 0 0 1-2 3.02v2.5h3.23c1.9-1.75 2.97-4.33 2.97-7.31Z"
      />
      <path
        fill="#34A853"
        d="M10 20c2.7 0 4.96-.89 6.62-2.42l-3.23-2.5c-.9.6-2.05.95-3.4.95-2.6 0-4.8-1.76-5.6-4.12H1.06v2.59A10 10 0 0 0 10 20Z"
      />
      <path
        fill="#FBBC05"
        d="M4.4 11.9a6 6 0 0 1 0-3.8V5.5H1.06a10 10 0 0 0 0 9l3.34-2.6Z"
      />
      <path
        fill="#EA4335"
        d="M10 3.98c1.47 0 2.79.5 3.83 1.5l2.87-2.87A9.7 9.7 0 0 0 10 0 10 10 0 0 0 1.06 5.5l3.34 2.6C5.2 5.74 7.4 3.98 10 3.98Z"
      />
    </svg>
  );
}

function GitHubIcon() {
  return (
    <svg viewBox="0 0 20 20" fill="currentColor" className="h-4.5 w-4.5" aria-hidden="true">
      <path
        fillRule="evenodd"
        d="M10 0C4.48 0 0 4.58 0 10.23c0 4.52 2.87 8.35 6.84 9.7.5.1.68-.22.68-.49 0-.24-.01-1.04-.01-1.88-2.51.55-3.24-1.08-3.24-1.08-.44-1.13-1.06-1.43-1.06-1.43-.87-.6.07-.59.07-.59.96.07 1.47 1 1.47 1 .85 1.48 2.24 1.05 2.79.8.08-.63.33-1.05.6-1.29-2.01-.23-4.12-1.02-4.12-4.53 0-1 .35-1.82.92-2.46-.09-.23-.4-1.17.09-2.44 0 0 .76-.25 2.48.94a8.5 8.5 0 0 1 4.52 0c1.72-1.19 2.48-.94 2.48-.94.49 1.27.18 2.21.09 2.44.57.64.92 1.46.92 2.46 0 3.52-2.11 4.29-4.13 4.52.34.3.63.87.63 1.76 0 1.27-.01 2.29-.01 2.6 0 .27.18.6.69.49A10.02 10.02 0 0 0 20 10.23C20 4.58 15.52 0 10 0Z"
        clipRule="evenodd"
      />
    </svg>
  );
}

/**
 * Social auth buttons — UI only. Wire onGoogleClick / onGithubClick to your
 * OAuth flow (redirect, popup, etc.) once the Django backend is connected.
 */
export default function SocialLogin({
  onGoogleClick,
  onGithubClick,
  loadingProvider = null,
  disabled = false,
  className = "",
}) {
  return (
    <div className={`flex flex-col gap-3 sm:flex-row ${className}`}>
      <Button
        type="button"
        variant="outline"
        fullWidth
        onClick={onGoogleClick}
        loading={loadingProvider === "google"}
        disabled={disabled}
        leftIcon={<GoogleIcon />}
        aria-label="Continue with Google"
      >
        Google
      </Button>
      <Button
        type="button"
        variant="outline"
        fullWidth
        onClick={onGithubClick}
        loading={loadingProvider === "github"}
        disabled={disabled}
        leftIcon={<GitHubIcon />}
        aria-label="Continue with GitHub"
      >
        GitHub
      </Button>
    </div>
  );
}
